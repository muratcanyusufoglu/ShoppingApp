const increaseNumber = () => ({
    type:"INC_NUMBER",
})

const decreaseNumber = () => ({
    type:"DEC_NUMBER",
})

export {increaseNumber,decreaseNumber}